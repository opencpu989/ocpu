OpenCPU App: Nabel
------------------

Simple OpenCPU Application. To install in R:

    library(devtools)
    install_github("nabel", "opencpu")

    library(opencpu)
    opencpu$browse("/library/nabel/www")

Use the same function locally:

    library(nabel)
    nabel()
    ?nabel

For more information about OpenCPU apps, see [opencpu.js](https://github.com/jeroenooms/opencpu.js#readme)
